const express = require('express')
const { Server } = require('http')
const app = express()
const port = 3000
app.get('/', (req, res) =>{
    res.send('<h2> witoj </h2>')
})
app.listen(port, ()=>{
    console.log("server działa na http://localhost:${port}")
})